from flask import Blueprint, render_template, request, jsonify
from src.models.user import User, Video, Stream, db
from sqlalchemy import or_

search_bp = Blueprint('search', __name__)

@search_bp.route('/')
def index():
    query = request.args.get('q', '')
    filter_type = request.args.get('type', 'all')
    
    if not query:
        return render_template('search/index.html', query=query, results=None)
    
    # Search for videos
    if filter_type == 'all' or filter_type == 'videos':
        videos = Video.query.filter(
            or_(
                Video.title.ilike(f'%{query}%'),
                Video.description.ilike(f'%{query}%')
            )
        ).all()
    else:
        videos = []
    
    # Search for streams
    if filter_type == 'all' or filter_type == 'streams':
        streams = Stream.query.filter(
            or_(
                Stream.title.ilike(f'%{query}%'),
                Stream.description.ilike(f'%{query}%')
            )
        ).all()
    else:
        streams = []
    
    # Search for users
    if filter_type == 'all' or filter_type == 'users':
        users = User.query.filter(
            or_(
                User.username.ilike(f'%{query}%'),
                User.bio.ilike(f'%{query}%')
            )
        ).all()
    else:
        users = []
    
    return render_template(
        'search/index.html',
        query=query,
        filter_type=filter_type,
        videos=videos,
        streams=streams,
        users=users
    )

@search_bp.route('/api')
def api():
    query = request.args.get('q', '')
    filter_type = request.args.get('type', 'all')
    
    if not query:
        return jsonify({'results': []})
    
    results = []
    
    # Search for videos
    if filter_type == 'all' or filter_type == 'videos':
        videos = Video.query.filter(
            or_(
                Video.title.ilike(f'%{query}%'),
                Video.description.ilike(f'%{query}%')
            )
        ).limit(5).all()
        
        for video in videos:
            results.append({
                'id': video.id,
                'title': video.title,
                'type': 'video',
                'thumbnail': video.thumbnail_url,
                'creator': video.creator.username,
                'views': video.views,
                'url': f'/video/{video.id}'
            })
    
    # Search for streams
    if filter_type == 'all' or filter_type == 'streams':
        streams = Stream.query.filter(
            or_(
                Stream.title.ilike(f'%{query}%'),
                Stream.description.ilike(f'%{query}%')
            )
        ).limit(5).all()
        
        for stream in streams:
            results.append({
                'id': stream.id,
                'title': stream.title,
                'type': 'stream',
                'thumbnail': stream.thumbnail_url,
                'creator': stream.streamer.username,
                'is_live': stream.is_live,
                'url': f'/stream/{stream.id}'
            })
    
    # Search for users
    if filter_type == 'all' or filter_type == 'users':
        users = User.query.filter(
            or_(
                User.username.ilike(f'%{query}%'),
                User.bio.ilike(f'%{query}%')
            )
        ).limit(5).all()
        
        for user in users:
            results.append({
                'id': user.id,
                'username': user.username,
                'type': 'user',
                'profile_picture': user.profile_picture,
                'is_streamer': user.is_streamer,
                'url': f'/user/{user.username}'
            })
    
    return jsonify({'results': results})

@search_bp.route('/discover')
def discover():
    # Get trending videos
    trending_videos = Video.query.order_by(Video.views.desc()).limit(8).all()
    
    # Get live streams
    live_streams = Stream.query.filter_by(is_live=True).order_by(Stream.viewers_count.desc()).limit(8).all()
    
    # Get popular streamers
    popular_streamers = User.query.filter_by(is_streamer=True).order_by(db.func.random()).limit(8).all()
    
    return render_template(
        'search/discover.html',
        trending_videos=trending_videos,
        live_streams=live_streams,
        popular_streamers=popular_streamers
    )
