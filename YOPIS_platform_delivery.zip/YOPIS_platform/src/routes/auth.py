from flask import Blueprint, render_template, redirect, url_for, flash, request, session, current_app
from flask_login import login_user, logout_user, login_required, current_user
from authlib.integrations.flask_client import OAuth
from src.models.user import User, db
import os
import json
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

oauth = OAuth()

@auth_bp.record_once
def on_load(state):
    app = state.app
    oauth.init_app(app)
    
    # Google OAuth setup
    oauth.register(
        name='google',
        client_id=os.getenv('GOOGLE_CLIENT_ID', 'dummy-client-id'),
        client_secret=os.getenv('GOOGLE_CLIENT_SECRET', 'dummy-client-secret'),
        server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
        client_kwargs={
            'scope': 'openid email profile'
        }
    )

@auth_bp.route('/login')
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    return render_template('auth/login.html')

@auth_bp.route('/login/google')
def google_login():
    redirect_uri = url_for('auth.google_authorize', _external=True)
    return oauth.google.authorize_redirect(redirect_uri)

@auth_bp.route('/login/google/authorize')
def google_authorize():
    try:
        token = oauth.google.authorize_access_token()
        user_info = oauth.google.parse_id_token(token)
        
        # Check if user exists
        user = User.query.filter_by(email=user_info['email']).first()
        
        if not user:
            # Create new user
            username = user_info['email'].split('@')[0]
            # Check if username exists
            existing_username = User.query.filter_by(username=username).first()
            if existing_username:
                username = f"{username}{datetime.now().strftime('%Y%m%d%H%M%S')}"
                
            user = User(
                email=user_info['email'],
                username=username,
                google_id=user_info['sub'],
                profile_picture=user_info.get('picture', None)
            )
            db.session.add(user)
            db.session.commit()
        else:
            # Update existing user's Google ID if not set
            if not user.google_id:
                user.google_id = user_info['sub']
                user.profile_picture = user_info.get('picture', user.profile_picture)
                db.session.commit()
        
        # Log in the user
        login_user(user)
        flash('تم تسجيل الدخول بنجاح!', 'success')
        
        # Redirect to next page or home
        next_page = session.get('next', url_for('main.index'))
        return redirect(next_page)
    
    except Exception as e:
        flash(f'حدث خطأ أثناء تسجيل الدخول: {str(e)}', 'danger')
        return redirect(url_for('auth.login'))

@auth_bp.route('/register')
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    return render_template('auth/register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('تم تسجيل الخروج بنجاح!', 'success')
    return redirect(url_for('main.index'))
