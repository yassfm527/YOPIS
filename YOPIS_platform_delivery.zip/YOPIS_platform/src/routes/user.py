from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from src.models.user import User, db
from werkzeug.security import generate_password_hash
from werkzeug.utils import secure_filename
import os
import uuid

user_bp = Blueprint('user', __name__)

@user_bp.route('/profile')
@login_required
def profile():
    return render_template('user/profile.html', user=current_user)

@user_bp.route('/settings')
@login_required
def settings():
    return render_template('user/settings.html', user=current_user)

@user_bp.route('/update_profile', methods=['POST'])
@login_required
def update_profile():
    if request.method == 'POST':
        username = request.form.get('username')
        bio = request.form.get('bio')
        
        # Check if username already exists
        if username != current_user.username:
            existing_user = User.query.filter_by(username=username).first()
            if existing_user:
                flash('اسم المستخدم موجود بالفعل، يرجى اختيار اسم آخر', 'danger')
                return redirect(url_for('user.settings'))
        
        # Update user profile
        current_user.username = username
        current_user.bio = bio
        
        # Handle profile picture upload
        if 'profile_picture' in request.files:
            file = request.files['profile_picture']
            if file and file.filename != '':
                # Generate unique filename
                filename = secure_filename(file.filename)
                ext = filename.rsplit('.', 1)[1].lower()
                new_filename = f"{uuid.uuid4().hex}.{ext}"
                
                # Save file
                upload_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'uploads', 'profile_pictures')
                os.makedirs(upload_folder, exist_ok=True)
                file_path = os.path.join(upload_folder, new_filename)
                file.save(file_path)
                
                # Update database
                current_user.profile_picture = f"/static/uploads/profile_pictures/{new_filename}"
        
        db.session.commit()
        flash('تم تحديث الملف الشخصي بنجاح', 'success')
        return redirect(url_for('user.profile'))

@user_bp.route('/change_password', methods=['POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Check if passwords match
        if new_password != confirm_password:
            flash('كلمات المرور غير متطابقة', 'danger')
            return redirect(url_for('user.settings'))
        
        # Update password
        current_user.password_hash = generate_password_hash(new_password)
        db.session.commit()
        
        flash('تم تغيير كلمة المرور بنجاح', 'success')
        return redirect(url_for('user.settings'))

@user_bp.route('/<username>')
def public_profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    return render_template('user/public_profile.html', user=user)

@user_bp.route('/dashboard')
@login_required
def dashboard():
    return render_template('user/dashboard.html', user=current_user)
