from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from src.models.user import User, Video, db
from werkzeug.utils import secure_filename
import os
import uuid
from datetime import datetime

video_bp = Blueprint('video', __name__)

# Helper function to check allowed file extensions
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'mp4', 'webm', 'mov', 'avi', 'mkv'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@video_bp.route('/')
def index():
    videos = Video.query.order_by(Video.created_at.desc()).limit(12).all()
    return render_template('video/index.html', videos=videos)

@video_bp.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'video' not in request.files:
            flash('لم يتم اختيار ملف فيديو', 'danger')
            return redirect(request.url)
        
        file = request.files['video']
        
        # If user does not select file, browser also submits an empty part without filename
        if file.filename == '':
            flash('لم يتم اختيار ملف فيديو', 'danger')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            # Generate unique filename
            filename = secure_filename(file.filename)
            ext = filename.rsplit('.', 1)[1].lower()
            new_filename = f"{uuid.uuid4().hex}.{ext}"
            
            # Create upload directory if it doesn't exist
            upload_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'uploads', 'videos')
            os.makedirs(upload_folder, exist_ok=True)
            
            # Save the file
            file_path = os.path.join(upload_folder, new_filename)
            file.save(file_path)
            
            # Get form data
            title = request.form.get('title')
            description = request.form.get('description')
            
            # Handle thumbnail upload
            thumbnail_url = None
            if 'thumbnail' in request.files:
                thumbnail = request.files['thumbnail']
                if thumbnail and thumbnail.filename != '':
                    # Generate unique filename for thumbnail
                    thumb_filename = secure_filename(thumbnail.filename)
                    thumb_ext = thumb_filename.rsplit('.', 1)[1].lower()
                    new_thumb_filename = f"{uuid.uuid4().hex}.{thumb_ext}"
                    
                    # Create thumbnails directory if it doesn't exist
                    thumbnail_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'uploads', 'thumbnails')
                    os.makedirs(thumbnail_folder, exist_ok=True)
                    
                    # Save the thumbnail
                    thumb_path = os.path.join(thumbnail_folder, new_thumb_filename)
                    thumbnail.save(thumb_path)
                    thumbnail_url = f"/static/uploads/thumbnails/{new_thumb_filename}"
            
            # Create new video record
            new_video = Video(
                title=title,
                description=description,
                video_url=f"/static/uploads/videos/{new_filename}",
                thumbnail_url=thumbnail_url,
                user_id=current_user.id
            )
            
            db.session.add(new_video)
            db.session.commit()
            
            flash('تم رفع الفيديو بنجاح!', 'success')
            return redirect(url_for('video.view', video_id=new_video.id))
        else:
            flash('نوع الملف غير مسموح به. الأنواع المسموح بها: mp4, webm, mov, avi, mkv', 'danger')
            return redirect(request.url)
    
    return render_template('video/upload.html')

@video_bp.route('/<int:video_id>')
def view(video_id):
    video = Video.query.get_or_404(video_id)
    
    # Increment view count
    video.views += 1
    db.session.commit()
    
    # Get related videos
    related_videos = Video.query.filter(Video.id != video_id).order_by(db.func.random()).limit(6).all()
    
    return render_template('video/view.html', video=video, related_videos=related_videos)

@video_bp.route('/<int:video_id>/like', methods=['POST'])
@login_required
def like(video_id):
    video = Video.query.get_or_404(video_id)
    
    # Increment like count (in a real app, you'd track which users liked which videos)
    video.likes += 1
    db.session.commit()
    
    return jsonify({'success': True, 'likes': video.likes})

@video_bp.route('/<int:video_id>/delete', methods=['POST'])
@login_required
def delete(video_id):
    video = Video.query.get_or_404(video_id)
    
    # Check if current user is the owner of the video
    if video.user_id != current_user.id:
        flash('ليس لديك صلاحية لحذف هذا الفيديو', 'danger')
        return redirect(url_for('video.view', video_id=video_id))
    
    # Delete the video file
    if video.video_url:
        video_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), video.video_url.lstrip('/'))
        if os.path.exists(video_path):
            os.remove(video_path)
    
    # Delete the thumbnail file
    if video.thumbnail_url:
        thumbnail_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), video.thumbnail_url.lstrip('/'))
        if os.path.exists(thumbnail_path):
            os.remove(thumbnail_path)
    
    # Delete the database record
    db.session.delete(video)
    db.session.commit()
    
    flash('تم حذف الفيديو بنجاح', 'success')
    return redirect(url_for('user.profile'))
