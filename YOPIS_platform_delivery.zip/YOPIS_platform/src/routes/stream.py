from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from src.models.user import User, Stream, db
import os
import uuid
from datetime import datetime

stream_bp = Blueprint('stream', __name__)

@stream_bp.route('/')
def index():
    # Get all active streams
    active_streams = Stream.query.filter_by(is_live=True).all()
    return render_template('stream/index.html', streams=active_streams)

@stream_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        
        # Generate unique stream key
        stream_key = uuid.uuid4().hex
        
        # Handle thumbnail upload
        thumbnail_url = None
        if 'thumbnail' in request.files:
            thumbnail = request.files['thumbnail']
            if thumbnail and thumbnail.filename != '':
                # Generate unique filename for thumbnail
                filename = thumbnail.filename
                ext = filename.rsplit('.', 1)[1].lower()
                new_filename = f"{uuid.uuid4().hex}.{ext}"
                
                # Create thumbnails directory if it doesn't exist
                thumbnail_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'uploads', 'thumbnails')
                os.makedirs(thumbnail_folder, exist_ok=True)
                
                # Save the thumbnail
                thumb_path = os.path.join(thumbnail_folder, new_filename)
                thumbnail.save(thumb_path)
                thumbnail_url = f"/static/uploads/thumbnails/{new_filename}"
        
        # Create new stream
        new_stream = Stream(
            title=title,
            description=description,
            stream_key=stream_key,
            thumbnail_url=thumbnail_url,
            user_id=current_user.id
        )
        
        db.session.add(new_stream)
        db.session.commit()
        
        flash('تم إنشاء البث المباشر بنجاح!', 'success')
        return redirect(url_for('stream.dashboard', stream_id=new_stream.id))
    
    return render_template('stream/create.html')

@stream_bp.route('/<int:stream_id>')
def view(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Increment viewers count if stream is live
    if stream.is_live:
        stream.viewers_count += 1
        db.session.commit()
    
    return render_template('stream/view.html', stream=stream)

@stream_bp.route('/<int:stream_id>/dashboard')
@login_required
def dashboard(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner of the stream
    if stream.user_id != current_user.id:
        flash('ليس لديك صلاحية للوصول إلى لوحة التحكم لهذا البث', 'danger')
        return redirect(url_for('stream.view', stream_id=stream_id))
    
    return render_template('stream/dashboard.html', stream=stream)

@stream_bp.route('/<int:stream_id>/start', methods=['POST'])
@login_required
def start(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner of the stream
    if stream.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'ليس لديك صلاحية لبدء هذا البث'}), 403
    
    # Start the stream
    stream.is_live = True
    stream.started_at = datetime.utcnow()
    stream.ended_at = None
    db.session.commit()
    
    return jsonify({'success': True})

@stream_bp.route('/<int:stream_id>/end', methods=['POST'])
@login_required
def end(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner of the stream
    if stream.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'ليس لديك صلاحية لإنهاء هذا البث'}), 403
    
    # End the stream
    stream.is_live = False
    stream.ended_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({'success': True})

@stream_bp.route('/<int:stream_id>/delete', methods=['POST'])
@login_required
def delete(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner of the stream
    if stream.user_id != current_user.id:
        flash('ليس لديك صلاحية لحذف هذا البث', 'danger')
        return redirect(url_for('stream.view', stream_id=stream_id))
    
    # Delete the thumbnail file if exists
    if stream.thumbnail_url:
        thumbnail_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), stream.thumbnail_url.lstrip('/'))
        if os.path.exists(thumbnail_path):
            os.remove(thumbnail_path)
    
    # Delete the stream
    db.session.delete(stream)
    db.session.commit()
    
    flash('تم حذف البث المباشر بنجاح', 'success')
    return redirect(url_for('user.profile'))
